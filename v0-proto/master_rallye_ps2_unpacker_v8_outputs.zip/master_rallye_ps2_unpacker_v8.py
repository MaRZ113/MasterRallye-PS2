#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

# BX chain parser prototype for Master Rallye PS2
# Detects compact BX records that start with either:
#   00 00 00 01 <rid>
#   00 00 01 <rid>
# followed by a 5-byte tag.
# This is a research parser, not a final extractor.


def find_record_starts(data: bytes, max_rid: int = 16):
    out = []
    i = 0
    n = len(data)
    while i < n - 10:
        hit = None
        if data[i:i+4] == b'\x00\x00\x00\x01' and 1 <= data[i+4] <= max_rid:
            hit = (i, 5, data[i+4])
        elif data[i:i+3] == b'\x00\x00\x01' and 1 <= data[i+3] <= max_rid:
            hit = (i, 4, data[i+3])
        if hit:
            pos, prefix_len, rid = hit
            tag = data[pos+prefix_len:pos+prefix_len+5]
            out.append((pos, prefix_len, rid, tag))
            i += prefix_len + 5
        else:
            i += 1
    return out


def parse_chains(data: bytes, max_gap: int = 0x1000, max_rid: int = 16):
    starts = find_record_starts(data, max_rid=max_rid)
    chains = []
    cur = []
    for idx, rec in enumerate(starts):
        pos, prefix_len, rid, tag = rec
        if not cur:
            cur = [rec]
            continue
        prev_pos, _, prev_rid, _ = cur[-1]
        if pos - prev_pos <= max_gap and rid == prev_rid + 1:
            cur.append(rec)
        else:
            chains.append(cur)
            cur = [rec]
    if cur:
        chains.append(cur)

    parsed = []
    for chain in chains:
        items = []
        for j, (pos, prefix_len, rid, tag) in enumerate(chain):
            next_pos = chain[j+1][0] if j + 1 < len(chain) else None
            payload_start = pos + prefix_len + 5
            payload_len = (next_pos - payload_start) if next_pos is not None else None
            items.append({
                'start': pos,
                'prefix_len': prefix_len,
                'rid': rid,
                'tag_hex': tag.hex(),
                'tag_ascii': ''.join(chr(c) if 32 <= c < 127 else '.' for c in tag),
                'payload_start': payload_start,
                'payload_len': payload_len,
            })
        parsed.append(items)
    return parsed


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('parse-bx-chains')
    p.add_argument('input', type=Path)
    p.add_argument('out_prefix', type=Path)

    ns = ap.parse_args()
    if ns.cmd == 'parse-bx-chains':
        data = ns.input.read_bytes()
        chains = parse_chains(data)
        ns.out_prefix.parent.mkdir(parents=True, exist_ok=True)
        (ns.out_prefix.with_suffix('.json')).write_text(json.dumps(chains, ensure_ascii=False, indent=2), encoding='utf-8')
        with (ns.out_prefix.with_suffix('.csv')).open('w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(['chain_index','record_index','start','prefix_len','rid','tag_hex','tag_ascii','payload_start','payload_len'])
            for ci, chain in enumerate(chains):
                for ri, item in enumerate(chain):
                    w.writerow([ci, ri, item['start'], item['prefix_len'], item['rid'], item['tag_hex'], item['tag_ascii'], item['payload_start'], item['payload_len']])
        summary = []
        summary.append(f'input: {ns.input.name}')
        summary.append(f'chains: {len(chains)}')
        for ci, chain in enumerate(chains[:20]):
            tags = ' | '.join(f"{r['rid']}:{r['tag_ascii']}" for r in chain)
            summary.append(f'chain {ci}: {tags}')
        (ns.out_prefix.with_suffix('.txt')).write_text('\n'.join(summary), encoding='utf-8')
        print('\n'.join(summary))

if __name__ == '__main__':
    main()
