#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, re
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Tuple

PRIMARY = [b'BX*Hd', b'BX91', b'BXA0', b'BXI1']
SECONDARY = [b'BXBa', b'BXQ', b'BXT', b'BXU', b'BX{', b'BX5', b'B^', b'C']

@dataclass
class Marker:
    offset: int
    tag: str
    rec_id: int | None
    prev_hex: str

@dataclass
class Cluster:
    index: int
    start: int
    end: int
    span: int
    tags: str
    rec_ids: str
    count: int
    has_primary_chain: bool
    notes: str


def find_all(data: bytes, pat: bytes) -> List[int]:
    out=[]; s=0
    while True:
        i=data.find(pat, s)
        if i==-1: break
        out.append(i)
        s=i+1
    return out


def collect_markers(data: bytes) -> List[Marker]:
    pats = PRIMARY + [b'BXBa']
    hits=[]
    for p in pats:
        for off in find_all(data, p):
            prev = data[max(0, off-4):off]
            rec_id = prev[-1] if len(prev)==4 else None
            hits.append(Marker(off, p.decode('latin1', 'replace'), rec_id, prev.hex()))
    hits.sort(key=lambda x: x.offset)
    return hits


def cluster_markers(markers: List[Marker], max_gap: int = 2048) -> List[Cluster]:
    groups=[]
    for m in markers:
        if not groups or m.offset - groups[-1][-1].offset > max_gap:
            groups.append([m])
        else:
            groups[-1].append(m)
    out=[]
    for idx, grp in enumerate(groups):
        tags=[m.tag for m in grp]
        rec_ids=[str(m.rec_id) for m in grp if m.rec_id is not None]
        prim = [t for t in tags if t in [p.decode() for p in PRIMARY]]
        has_chain = prim[:4] == ['BX*Hd','BX91','BXA0','BXI1'] or prim[:3] == ['BX*Hd','BX91','BXA0']
        notes=[]
        if has_chain:
            notes.append('primary_chain')
        if any(t=='BXBa' for t in tags):
            notes.append('has_BXBa')
        if rec_ids:
            notes.append('rec_ids=' + ','.join(rec_ids))
        out.append(Cluster(
            idx,
            grp[0].offset,
            grp[-1].offset,
            grp[-1].offset - grp[0].offset,
            '|'.join(tags),
            ','.join(rec_ids),
            len(grp),
            has_chain,
            ';'.join(notes)
        ))
    return out


def carve_window(src: Path, offset: int, size: int, out: Path) -> None:
    with src.open('rb') as f:
        f.seek(offset)
        blob=f.read(size)
    out.write_bytes(blob)


def cmd_analyze_bx(inp: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    data = inp.read_bytes()
    markers = collect_markers(data)
    clusters = cluster_markers(markers)

    (out_dir / (inp.stem + '_bx_markers.json')).write_text(
        json.dumps([asdict(m) for m in markers], ensure_ascii=False, indent=2), encoding='utf-8')
    (out_dir / (inp.stem + '_bx_clusters.json')).write_text(
        json.dumps([asdict(c) for c in clusters], ensure_ascii=False, indent=2), encoding='utf-8')

    with (out_dir / (inp.stem + '_bx_clusters.csv')).open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(asdict(clusters[0]).keys()) if clusters else ['index','start','end','span','tags','rec_ids','count','has_primary_chain','notes'])
        w.writeheader()
        for c in clusters:
            w.writerow(asdict(c))

    summary=[]
    summary.append(f'file: {inp.name}')
    summary.append(f'size: {len(data)}')
    summary.append(f'total markers: {len(markers)}')
    summary.append(f'total clusters: {len(clusters)}')
    summary.append('clusters:')
    for c in clusters:
        summary.append(f'  #{c.index} 0x{c.start:X}-0x{c.end:X} span=0x{c.span:X} count={c.count} primary={c.has_primary_chain} tags={c.tags} notes={c.notes}')
    (out_dir / (inp.stem + '_bx_summary.txt')).write_text('\n'.join(summary), encoding='utf-8')
    print('\n'.join(summary))


def main():
    ap=argparse.ArgumentParser(description='Master Rallye PS2 BX analyzer v4')
    sub=ap.add_subparsers(dest='cmd', required=True)

    p1=sub.add_parser('analyze-bx')
    p1.add_argument('input', type=Path)
    p1.add_argument('out_dir', type=Path)

    p2=sub.add_parser('carve-window')
    p2.add_argument('src', type=Path)
    p2.add_argument('offset', type=lambda x:int(x,0))
    p2.add_argument('size', type=lambda x:int(x,0))
    p2.add_argument('out', type=Path)

    ns=ap.parse_args()
    if ns.cmd=='analyze-bx':
        cmd_analyze_bx(ns.input, ns.out_dir)
    elif ns.cmd=='carve-window':
        carve_window(ns.src, ns.offset, ns.size, ns.out)
        print(f'wrote {ns.out}')

if __name__=='__main__':
    main()
