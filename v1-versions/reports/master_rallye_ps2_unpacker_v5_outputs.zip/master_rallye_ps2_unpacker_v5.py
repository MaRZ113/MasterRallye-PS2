#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, mmap, re, sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Tuple

PRIMARY = [b'BX*Hd', b'BX91', b'BXA0', b'BXI1']
VARIANTS = [b'BXBa', b'BXU', b'BXQ', b'BXT', b'BX{']
ALL = PRIMARY + VARIANTS

@dataclass
class Marker:
    offset: int
    tag: str

@dataclass
class Cluster:
    start: int
    end: int
    size: int
    shape: str
    tags: str
    count: int


def find_markers(data: bytes) -> List[Marker]:
    out=[]
    for pat in ALL:
        for m in re.finditer(re.escape(pat), data):
            out.append(Marker(m.start(), pat.decode('latin1')))
    return sorted(out, key=lambda x: x.offset)


def cluster_markers(markers: List[Marker], gap: int = 512) -> List[List[Marker]]:
    if not markers:
        return []
    groups=[[markers[0]]]
    for m in markers[1:]:
        if m.offset - groups[-1][-1].offset <= gap:
            groups[-1].append(m)
        else:
            groups.append([m])
    return groups


def cluster_shape(group: List[Marker]) -> str:
    tags=[m.tag for m in group]
    if tags[:4] == ['BX*Hd','BX91','BXA0','BXI1']:
        return 'primary_chain'
    if tags[:3] == ['BX*Hd','BX91','BXA0']:
        return 'primary_chain_no4'
    if tags[:3] == ['BX91','BXBa','BX{']:
        return 'variant_chain'
    return 'mixed'


def analyze_bytes(data: bytes, gap: int = 512) -> Tuple[List[Marker], List[Cluster]]:
    markers=find_markers(data)
    groups=cluster_markers(markers, gap=gap)
    clusters=[]
    for g in groups:
        start=g[0].offset
        end=g[-1].offset + 5
        clusters.append(Cluster(start, end, end-start, cluster_shape(g), '|'.join(m.tag for m in g), len(g)))
    return markers, clusters


def write_csv(path: Path, rows: List[dict]):
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def cmd_analyze_bx(args):
    data=Path(args.src).read_bytes()
    markers, clusters = analyze_bytes(data, gap=args.gap)
    outdir=Path(args.out_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    write_csv(outdir/'markers.csv', [asdict(m) for m in markers])
    write_csv(outdir/'clusters.csv', [asdict(c) for c in clusters])
    (outdir/'summary.txt').write_text('\n'.join([
        f'source: {args.src}',
        f'markers: {len(markers)}',
        f'clusters: {len(clusters)}',
        *[f"0x{c.start:X}-0x{c.end:X} {c.shape} {c.tags}" for c in clusters]
    ]), encoding='utf-8')
    print(f'markers={len(markers)} clusters={len(clusters)} -> {outdir}')


def cmd_scan_bx_global(args):
    path=Path(args.src)
    outdir=Path(args.out_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    found=[]
    with path.open('rb') as f:
        mm=mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        size=mm.size()
        # find all markers globally
        markers=[]
        for pat in ALL:
            pos=0
            while True:
                i=mm.find(pat, pos)
                if i == -1:
                    break
                markers.append(Marker(i, pat.decode('latin1')))
                pos=i+1
        mm.close()
    markers=sorted(markers, key=lambda x: x.offset)
    groups=cluster_markers(markers, gap=args.gap)
    clusters=[]
    for g in groups:
        start=g[0].offset
        end=g[-1].offset+5
        clusters.append(Cluster(start,end,end-start,cluster_shape(g),'|'.join(m.tag for m in g),len(g)))
    write_csv(outdir/'global_markers.csv', [asdict(m) for m in markers])
    write_csv(outdir/'global_clusters.csv', [asdict(c) for c in clusters])
    (outdir/'global_summary.txt').write_text('\n'.join([
        f'source: {args.src}',
        f'markers: {len(markers)}',
        f'clusters: {len(clusters)}',
        *[f"0x{c.start:X}-0x{c.end:X} {c.shape} {c.tags}" for c in clusters[:300]]
    ]), encoding='utf-8')
    print(f'global markers={len(markers)} clusters={len(clusters)} -> {outdir}')


def cmd_carve_window(args):
    src=Path(args.src); out=Path(args.out)
    with src.open('rb') as f:
        f.seek(int(args.offset,0) if isinstance(args.offset,str) else args.offset)
        data=f.read(int(args.size,0) if isinstance(args.size,str) else args.size)
    out.write_bytes(data)
    print(f'wrote {out} ({len(data)} bytes)')


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest='cmd', required=True)
    a=sub.add_parser('analyze-bx'); a.add_argument('src'); a.add_argument('out_dir'); a.add_argument('--gap', type=int, default=512); a.set_defaults(func=cmd_analyze_bx)
    g=sub.add_parser('scan-bx-global'); g.add_argument('src'); g.add_argument('out_dir'); g.add_argument('--gap', type=int, default=512); g.set_defaults(func=cmd_scan_bx_global)
    c=sub.add_parser('carve-window'); c.add_argument('src'); c.add_argument('offset'); c.add_argument('size'); c.add_argument('out'); c.set_defaults(func=cmd_carve_window)
    args=ap.parse_args(); args.func(args)

if __name__ == '__main__':
    main()
