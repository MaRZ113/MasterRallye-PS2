#!/usr/bin/env python3
from pathlib import Path
import zipfile, shutil, hashlib, zlib, pandas as pd

# Rebuild full TNG.000 from the split zip parts, verify integrity, then promote the
# manually validated 43fc98 rank07 candidate into the family-aware atlas.
# This script mirrors the stage18 artifact reconstruction performed in ChatGPT.
